/***
 * Demo program to flash 8 external LEDs + 1 onboard LED (GPIO25)
 * Uses FreeRTOS Task
 */

#include "pico/stdlib.h"

#include "FreeRTOS.h"
#include "task.h"
#include <stdio.h>

#include "BlinkAgent.h"

//Standard Task priority
#define TASK_PRIORITY ( tskIDLE_PRIORITY + 1UL )

// LED GPIO
#define LED0_PAD 25   // onboard LED
#define LED1_PAD 0
#define LED2_PAD 1
#define LED3_PAD 2
#define LED4_PAD 3
#define LED5_PAD 4
#define LED6_PAD 5
#define LED7_PAD 6
#define LED8_PAD 7


void runTimeStats(){
    TaskStatus_t *pxTaskStatusArray;
    volatile UBaseType_t uxArraySize, x;
    unsigned long ulTotalRunTime;

    uxArraySize = uxTaskGetNumberOfTasks();
    printf("Number of tasks %d\n", uxArraySize);

    pxTaskStatusArray = (TaskStatus_t *)pvPortMalloc( uxArraySize * sizeof(TaskStatus_t));

    if(pxTaskStatusArray != NULL){

        uxArraySize = uxTaskGetSystemState(
            pxTaskStatusArray,
            uxArraySize,
            &ulTotalRunTime
        );

        for(x = 0; x < uxArraySize; x++){
            printf("Task: %d  cPri:%d  bPri:%d  hw:%d  %s\n",
                pxTaskStatusArray[x].xTaskNumber,
                pxTaskStatusArray[x].uxCurrentPriority,
                pxTaskStatusArray[x].uxBasePriority,
                pxTaskStatusArray[x].usStackHighWaterMark,
                pxTaskStatusArray[x].pcTaskName
            );
        }

        vPortFree(pxTaskStatusArray);
    }

    HeapStats_t heapStats;
    vPortGetHeapStats(&heapStats);

    printf("HEAP avl:%d blocks:%d alloc:%d free:%d\n",
        heapStats.xAvailableHeapSpaceInBytes,
        heapStats.xNumberOfFreeBlocks,
        heapStats.xNumberOfSuccessfulAllocations,
        heapStats.xNumberOfSuccessfulFrees
    );
}


/*** Main task ***/
void mainTask(void *params){

    BlinkAgent led0(LED0_PAD);
    BlinkAgent led1(LED1_PAD);
    BlinkAgent led2(LED2_PAD);
    BlinkAgent led3(LED3_PAD);
    BlinkAgent led4(LED4_PAD);
    BlinkAgent led5(LED5_PAD);
    BlinkAgent led6(LED6_PAD);
    BlinkAgent led7(LED7_PAD);
    BlinkAgent led8(LED8_PAD);

    printf("Main task started\n");

    led0.start("Onboard LED", TASK_PRIORITY);
    led1.start("LED1", TASK_PRIORITY);
	vTaskDelay(100);
    led2.start("LED2", TASK_PRIORITY + 1);
	vTaskDelay(200);
    led3.start("LED3", TASK_PRIORITY + 2);
	vTaskDelay(300);
    led4.start("LED4", TASK_PRIORITY + 3);
	vTaskDelay(400);
    led5.start("LED5", TASK_PRIORITY + 1);
	vTaskDelay(500);
    led6.start("LED6", TASK_PRIORITY + 2);
	vTaskDelay(600);
    led7.start("LED7", TASK_PRIORITY + 3);
	vTaskDelay(700);
    led8.start("LED8", TASK_PRIORITY + 1);
	vTaskDelay(800);

    while(true){
        runTimeStats();
        vTaskDelay(3000);
    }
}


/*** Launch scheduler ***/
void vLaunch(void){

    TaskHandle_t task;

    xTaskCreate(
        mainTask,
        "MainThread",
        500,
        NULL,
        TASK_PRIORITY,
        &task
    );

    vTaskStartScheduler();
}


/*** Main ***/
int main(void){

    stdio_init_all();
    sleep_ms(2000);

    printf("GO\n");

    const char *rtos_name = "FreeRTOS";
    printf("Starting %s on core 0:\n", rtos_name);

    vLaunch();

    return 0;
}


/*** FreeRTOS Hook Functions ***/
extern "C" void vApplicationStackOverflowHook(TaskHandle_t xTask, char *pcTaskName){
    while(1);
}

extern "C" void vApplicationGetIdleTaskMemory(
    StaticTask_t **ppxIdleTaskTCBBuffer,
    StackType_t **ppxIdleTaskStackBuffer,
    uint32_t *pulIdleTaskStackSize){

    static StaticTask_t xIdleTaskTCB;
    static StackType_t uxIdleTaskStack[configMINIMAL_STACK_SIZE];

    *ppxIdleTaskTCBBuffer = &xIdleTaskTCB;
    *ppxIdleTaskStackBuffer = uxIdleTaskStack;
    *pulIdleTaskStackSize = configMINIMAL_STACK_SIZE;
}

extern "C" void vApplicationGetTimerTaskMemory(
    StaticTask_t **ppxTimerTaskTCBBuffer,
    StackType_t **ppxTimerTaskStackBuffer,
    uint32_t *pulTimerTaskStackSize){

    static StaticTask_t xTimerTaskTCB;
    static StackType_t uxTimerTaskStack[configTIMER_TASK_STACK_DEPTH];

    *ppxTimerTaskTCBBuffer = &xTimerTaskTCB;
    *ppxTimerTaskStackBuffer = uxTimerTaskStack;
    *pulTimerTaskStackSize = configTIMER_TASK_STACK_DEPTH;
}